package com.java.clinicalManagement;

import java.util.Date;

public class Appointment {
	
	public static Activity act ; 

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		// This Interface is generally called for making method as Factory Pattern 
		
		
		
		// For Registration of Patient 
		
		
		String patientRegistration = act.getRegisteration("Ranjan MIshra", new Date("16/04/1989"), "Father Name");
		
		System.out.println(patientRegistration);
		if(patientRegistration.equalsIgnoreCase("Y"))
		{
			String pAppointment = act.getAppointment("Ranjan MIshra", new Date("16/04/1989"), "Father Name","Pathology");
		}else 
		{
			System.out.println("Patient is already Registered");
			
			String patientPrevReport = act.getPreviousReport(new Date(15/04/2005)); // Report Date given by Patient
			String prevPatientNewAppointment = act.getAppointmentDate(new Long("25869"),new Date(15/04/2005));
			
			
		}
		
		
	}

}
