package com.java.clinicalManagement;

import java.util.Date;

public class ActivityClass  implements Activity{
	
	

	@Override
	public String getAppointment(String pName, Date pDob, String pFathName, String deptNo) throws Exception {
		// TODO Auto-generated method stub
		return "Get the New Appointment For Patient with Reference to Doctor";
	}

	@Override
	public String getAppointmentDate(Long docid, Date prevReportDate) throws Exception {
		// TODO Auto-generated method stub
		return "Based upon Docid and PrevReportDate newly appointment Date is given";
	}

	@Override
	public String getPreviousReport(Date prevDate) throws Exception {
		// TODO Auto-generated method stub
		return "Getting the previous Report ";
	}

	@Override
	public String getRegisteration(String pName, Date pDob, String pFathName)
			throws Exception {
		// TODO Auto-generated method stub
		
		Boolean isregistered = false;
		
		if(pName.equalsIgnoreCase("abc") || pFathName.equalsIgnoreCase("abc") || pDob.equals(new Date("16/04/1989")))
		{
			isregistered = true;	
			return "Patient is already Registered"+isregistered;
		}
		
		Patient pl = new Patient();
		pl.setpName(pName);
		pl.setpFatherName(pFathName);
		pl.setPdob(pDob);
		
		System.out.println("Patient" +pName +"is Registered Successfully");
		
		return "Patient" +pName +"is Registered Successfully"+isregistered;
	}

}
