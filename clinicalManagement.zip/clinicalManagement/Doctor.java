package com.java.clinicalManagement;

import java.util.*;;

public class Doctor {
	
	private Long id;
	private String name;
	private Integer age;
	private String deptNo;
	private String deptName;
	private Date  dob;
	
	
	
	public Doctor(Long id, String name, Integer age, String deptNo,
			String deptName, Date dob) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.dob = dob;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	
	
	

}
