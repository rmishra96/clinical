package com.java.clinicalManagement;

import java.util.*;;

public interface Activity {
	
	public String getRegisteration(String pName, Date pDob, String pFathName) throws Exception;
	
	public String getAppointment(String pName, Date pDob, String pFathName, String deptNo) throws Exception;
	
	public String getAppointmentDate(Long docid, Date prevReportDate) throws Exception;
	
	public String getPreviousReport(Date prevDate) throws Exception;
	

}
