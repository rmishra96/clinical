package com.java.clinicalManagement;

import java.util.Date;

public class Patient {
	
	private Long id;
	private String pName;
	private String pFatherName;
	private Date pdob;
	private Boolean isDiagonsis;
	private Date diagonsisDate;
	
	
	public Patient(){
		
	}
	
	
	public Patient(Long id, String pName, String pFatherName, Date pdob,
			Boolean isDiagonsis, Date diagonsisDate) {
		super();
		this.id = id;
		this.pName = pName;
		this.pFatherName = pFatherName;
		this.pdob = pdob;
		this.isDiagonsis = isDiagonsis;
		this.diagonsisDate = diagonsisDate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpFatherName() {
		return pFatherName;
	}
	public void setpFatherName(String pFatherName) {
		this.pFatherName = pFatherName;
	}
	public Date getPdob() {
		return pdob;
	}
	public void setPdob(Date pdob) {
		this.pdob = pdob;
	}
	public Boolean getIsDiagonsis() {
		return isDiagonsis;
	}
	public void setIsDiagonsis(Boolean isDiagonsis) {
		this.isDiagonsis = isDiagonsis;
	}
	public Date getDiagonsisDate() {
		return diagonsisDate;
	}
	public void setDiagonsisDate(Date diagonsisDate) {
		this.diagonsisDate = diagonsisDate;
	}
	
	
	
}
